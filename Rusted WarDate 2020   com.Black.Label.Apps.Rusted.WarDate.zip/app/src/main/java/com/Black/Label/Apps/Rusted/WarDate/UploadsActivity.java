package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class UploadsActivity extends AppCompatActivity {
	
	
	private FloatingActionButton _fab;
	
	private LinearLayout linear1;
	private LinearLayout pl;
	private LinearLayout main;
	private LinearLayout menu;
	private WebView webview1;
	private LinearLayout no_connection;
	private ImageView menu_back;
	private AdView adview2;
	private ScrollView vscroll1;
	private LinearLayout linear401;
	private LinearLayout addons;
	private LinearLayout linear400;
	private LinearLayout linear402;
	private LinearLayout linear403;
	private LinearLayout linear404;
	private LinearLayout linear497;
	private LinearLayout linear507;
	private LinearLayout linear499;
	private LinearLayout linear500;
	private LinearLayout linear501;
	private LinearLayout linear502;
	private LinearLayout linear503;
	private LinearLayout linear504;
	private LinearLayout linear505;
	private ImageView imageview72;
	private TextView home;
	private ImageView imageview107;
	private TextView maddons;
	private ImageView imageview108;
	private TextView mtotalconvertion;
	private ImageView imageview109;
	private TextView mmaps;
	private ImageView imageview110;
	private TextView muploads;
	private ImageView imageview111;
	private TextView mdownloads;
	private ImageView imageview112;
	private TextView textview274;
	private ImageView imageview113;
	private TextView textview275;
	private ImageView imageview114;
	private TextView textview276;
	private ImageView imageview115;
	private TextView textview277;
	private ImageView imageview116;
	private TextView textview278;
	private ImageView imagenoconnection;
	private TextView textnoconnection;
	private LinearLayout linear508;
	private ImageView imageview117;
	private TextView textview273;
	
	private Intent i = new Intent();
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.uploads);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		pl = (LinearLayout) findViewById(R.id.pl);
		main = (LinearLayout) findViewById(R.id.main);
		menu = (LinearLayout) findViewById(R.id.menu);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		no_connection = (LinearLayout) findViewById(R.id.no_connection);
		menu_back = (ImageView) findViewById(R.id.menu_back);
		adview2 = (AdView) findViewById(R.id.adview2);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear401 = (LinearLayout) findViewById(R.id.linear401);
		addons = (LinearLayout) findViewById(R.id.addons);
		linear400 = (LinearLayout) findViewById(R.id.linear400);
		linear402 = (LinearLayout) findViewById(R.id.linear402);
		linear403 = (LinearLayout) findViewById(R.id.linear403);
		linear404 = (LinearLayout) findViewById(R.id.linear404);
		linear497 = (LinearLayout) findViewById(R.id.linear497);
		linear507 = (LinearLayout) findViewById(R.id.linear507);
		linear499 = (LinearLayout) findViewById(R.id.linear499);
		linear500 = (LinearLayout) findViewById(R.id.linear500);
		linear501 = (LinearLayout) findViewById(R.id.linear501);
		linear502 = (LinearLayout) findViewById(R.id.linear502);
		linear503 = (LinearLayout) findViewById(R.id.linear503);
		linear504 = (LinearLayout) findViewById(R.id.linear504);
		linear505 = (LinearLayout) findViewById(R.id.linear505);
		imageview72 = (ImageView) findViewById(R.id.imageview72);
		home = (TextView) findViewById(R.id.home);
		imageview107 = (ImageView) findViewById(R.id.imageview107);
		maddons = (TextView) findViewById(R.id.maddons);
		imageview108 = (ImageView) findViewById(R.id.imageview108);
		mtotalconvertion = (TextView) findViewById(R.id.mtotalconvertion);
		imageview109 = (ImageView) findViewById(R.id.imageview109);
		mmaps = (TextView) findViewById(R.id.mmaps);
		imageview110 = (ImageView) findViewById(R.id.imageview110);
		muploads = (TextView) findViewById(R.id.muploads);
		imageview111 = (ImageView) findViewById(R.id.imageview111);
		mdownloads = (TextView) findViewById(R.id.mdownloads);
		imageview112 = (ImageView) findViewById(R.id.imageview112);
		textview274 = (TextView) findViewById(R.id.textview274);
		imageview113 = (ImageView) findViewById(R.id.imageview113);
		textview275 = (TextView) findViewById(R.id.textview275);
		imageview114 = (ImageView) findViewById(R.id.imageview114);
		textview276 = (TextView) findViewById(R.id.textview276);
		imageview115 = (ImageView) findViewById(R.id.imageview115);
		textview277 = (TextView) findViewById(R.id.textview277);
		imageview116 = (ImageView) findViewById(R.id.imageview116);
		textview278 = (TextView) findViewById(R.id.textview278);
		imagenoconnection = (ImageView) findViewById(R.id.imagenoconnection);
		textnoconnection = (TextView) findViewById(R.id.textnoconnection);
		linear508 = (LinearLayout) findViewById(R.id.linear508);
		imageview117 = (ImageView) findViewById(R.id.imageview117);
		textview273 = (TextView) findViewById(R.id.textview273);
		d = new AlertDialog.Builder(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		maddons.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		mtotalconvertion.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), TotalconvertionActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		mmaps.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), MapsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		muploads.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		mdownloads.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), DowloadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview274.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), NewsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview275.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ClashofwarfareActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview273.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ChatBotActivity.class);
				startActivity(i);
				finish();
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
