package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Button;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import android.content.Intent;
import android.content.ClipData;
import android.view.View;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class AppAddonsActivity extends AppCompatActivity {
	
	public final int REQ_CD_FPICK = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private double image = 0;
	private String ImageName = "";
	private String imagePath = "";
	private HashMap<String, Object> mapVar = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> publications = new ArrayList<>();
	private ArrayList<String> filePath = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> mapList = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout menu;
	private LinearLayout linear514;
	private ImageView menu_back;
	private AdView adview2;
	private ScrollView vscroll1;
	private LinearLayout linear401;
	private LinearLayout addons;
	private LinearLayout linear508;
	private LinearLayout linear400;
	private LinearLayout linear402;
	private LinearLayout linear403;
	private LinearLayout linear404;
	private LinearLayout linear497;
	private LinearLayout linear507;
	private LinearLayout linear499;
	private LinearLayout linear500;
	private LinearLayout linear501;
	private LinearLayout linear502;
	private LinearLayout linear503;
	private LinearLayout linear504;
	private LinearLayout linear505;
	private ImageView imageview72;
	private TextView home;
	private ImageView imageview117;
	private TextView textview279;
	private ImageView imageview107;
	private TextView maddons;
	private ImageView imageview108;
	private TextView mtotalconvertion;
	private ImageView imageview109;
	private TextView mmaps;
	private ImageView imageview110;
	private TextView muploads;
	private ImageView imageview111;
	private TextView mdownloads;
	private ImageView imageview112;
	private TextView textview274;
	private ImageView imageview113;
	private TextView textview275;
	private ImageView imageview114;
	private TextView textview276;
	private ImageView imageview115;
	private TextView textview277;
	private ImageView imageview116;
	private TextView textview278;
	private LinearLayout linear515;
	private ListView listview1;
	private LinearLayout main_app;
	private ImageView profile;
	private ImageView up_here;
	private TextView uphere;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear10;
	private EditText p_title;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private Button button2;
	private ImageView imageview3;
	private TextView pd_author;
	private EditText p_author;
	private TextView pd_description;
	private EditText p_description;
	private TextView pd_changelog;
	private EditText p_changelog;
	private TextView pd_languaje;
	private EditText p_languaje;
	private TextView pd_image;
	private ImageView p_image;
	private TextView pd_download;
	private ImageView p_download;
	
	private DatabaseReference db_posts_addons = _firebase.getReference("posts");
	private ChildEventListener _db_posts_addons_child_listener;
	private StorageReference storage_post_addons = _firebase_storage.getReference("storage_post_addons");
	private OnCompleteListener<Uri> _storage_post_addons_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _storage_post_addons_download_success_listener;
	private OnSuccessListener _storage_post_addons_delete_success_listener;
	private OnProgressListener _storage_post_addons_upload_progress_listener;
	private OnProgressListener _storage_post_addons_download_progress_listener;
	private OnFailureListener _storage_post_addons_failure_listener;
	private Intent fpick = new Intent(Intent.ACTION_GET_CONTENT);
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.app_addons);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = (LinearLayout) findViewById(R.id.main);
		menu = (LinearLayout) findViewById(R.id.menu);
		linear514 = (LinearLayout) findViewById(R.id.linear514);
		menu_back = (ImageView) findViewById(R.id.menu_back);
		adview2 = (AdView) findViewById(R.id.adview2);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear401 = (LinearLayout) findViewById(R.id.linear401);
		addons = (LinearLayout) findViewById(R.id.addons);
		linear508 = (LinearLayout) findViewById(R.id.linear508);
		linear400 = (LinearLayout) findViewById(R.id.linear400);
		linear402 = (LinearLayout) findViewById(R.id.linear402);
		linear403 = (LinearLayout) findViewById(R.id.linear403);
		linear404 = (LinearLayout) findViewById(R.id.linear404);
		linear497 = (LinearLayout) findViewById(R.id.linear497);
		linear507 = (LinearLayout) findViewById(R.id.linear507);
		linear499 = (LinearLayout) findViewById(R.id.linear499);
		linear500 = (LinearLayout) findViewById(R.id.linear500);
		linear501 = (LinearLayout) findViewById(R.id.linear501);
		linear502 = (LinearLayout) findViewById(R.id.linear502);
		linear503 = (LinearLayout) findViewById(R.id.linear503);
		linear504 = (LinearLayout) findViewById(R.id.linear504);
		linear505 = (LinearLayout) findViewById(R.id.linear505);
		imageview72 = (ImageView) findViewById(R.id.imageview72);
		home = (TextView) findViewById(R.id.home);
		imageview117 = (ImageView) findViewById(R.id.imageview117);
		textview279 = (TextView) findViewById(R.id.textview279);
		imageview107 = (ImageView) findViewById(R.id.imageview107);
		maddons = (TextView) findViewById(R.id.maddons);
		imageview108 = (ImageView) findViewById(R.id.imageview108);
		mtotalconvertion = (TextView) findViewById(R.id.mtotalconvertion);
		imageview109 = (ImageView) findViewById(R.id.imageview109);
		mmaps = (TextView) findViewById(R.id.mmaps);
		imageview110 = (ImageView) findViewById(R.id.imageview110);
		muploads = (TextView) findViewById(R.id.muploads);
		imageview111 = (ImageView) findViewById(R.id.imageview111);
		mdownloads = (TextView) findViewById(R.id.mdownloads);
		imageview112 = (ImageView) findViewById(R.id.imageview112);
		textview274 = (TextView) findViewById(R.id.textview274);
		imageview113 = (ImageView) findViewById(R.id.imageview113);
		textview275 = (TextView) findViewById(R.id.textview275);
		imageview114 = (ImageView) findViewById(R.id.imageview114);
		textview276 = (TextView) findViewById(R.id.textview276);
		imageview115 = (ImageView) findViewById(R.id.imageview115);
		textview277 = (TextView) findViewById(R.id.textview277);
		imageview116 = (ImageView) findViewById(R.id.imageview116);
		textview278 = (TextView) findViewById(R.id.textview278);
		linear515 = (LinearLayout) findViewById(R.id.linear515);
		listview1 = (ListView) findViewById(R.id.listview1);
		main_app = (LinearLayout) findViewById(R.id.main_app);
		profile = (ImageView) findViewById(R.id.profile);
		up_here = (ImageView) findViewById(R.id.up_here);
		uphere = (TextView) findViewById(R.id.uphere);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		p_title = (EditText) findViewById(R.id.p_title);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		button2 = (Button) findViewById(R.id.button2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		pd_author = (TextView) findViewById(R.id.pd_author);
		p_author = (EditText) findViewById(R.id.p_author);
		pd_description = (TextView) findViewById(R.id.pd_description);
		p_description = (EditText) findViewById(R.id.p_description);
		pd_changelog = (TextView) findViewById(R.id.pd_changelog);
		p_changelog = (EditText) findViewById(R.id.p_changelog);
		pd_languaje = (TextView) findViewById(R.id.pd_languaje);
		p_languaje = (EditText) findViewById(R.id.p_languaje);
		pd_image = (TextView) findViewById(R.id.pd_image);
		p_image = (ImageView) findViewById(R.id.p_image);
		pd_download = (TextView) findViewById(R.id.pd_download);
		p_download = (ImageView) findViewById(R.id.p_download);
		fpick.setType("image/*");
		fpick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
			}
		});
		
		up_here.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				uphere.setVisibility(View.VISIBLE);
				profile.setVisibility(View.VISIBLE);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (image == 0) {
					mapVar = new HashMap<>();
					mapVar.put("description_text", p_description.getText().toString());
					db_posts_addons.push().updateChildren(mapVar);
					mapVar.clear();
				}
				else {
					storage_post_addons.child(ImageName).putFile(Uri.fromFile(new File(imagePath))).addOnFailureListener(_storage_post_addons_failure_listener).addOnProgressListener(_storage_post_addons_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return storage_post_addons.child(ImageName).getDownloadUrl();
						}}).addOnCompleteListener(_storage_post_addons_upload_success_listener);
				}
			}
		});
		
		p_image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fpick, REQ_CD_FPICK);
			}
		});
		
		_db_posts_addons_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				db_posts_addons.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						mapList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								mapList.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						Collections.reverse(publications);
						listview1.setAdapter(new Listview1Adapter(mapList));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_posts_addons.addChildEventListener(_db_posts_addons_child_listener);
		
		_storage_post_addons_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_post_addons_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_post_addons_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				mapVar = new HashMap<>();
				mapVar.put("description_text", p_description.getText().toString());
				mapVar.put("image", _downloadUrl);
				db_posts_addons.push().updateChildren(mapVar);
				mapVar.clear();
				image = 0;
				p_image.setVisibility(View.GONE);
			}
		};
		
		_storage_post_addons_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_storage_post_addons_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_storage_post_addons_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
	}
	private void initializeLogic() {
		uphere.setVisibility(View.GONE);
		profile.setVisibility(View.GONE);
		image = 0;
		p_image.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FPICK:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				image = 1;
				p_image.setVisibility(View.INVISIBLE);
				p_image.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
				imagePath = _filePath.get((int)(0));
				ImageName = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.ejm_post, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView image_post = (ImageView) _v.findViewById(R.id.image_post);
			final TextView text_post = (TextView) _v.findViewById(R.id.text_post);
			
			Glide.with(getApplicationContext()).load(Uri.parse(mapList.get((int)_position).get("description_text").toString())).into(image_perfil);
			if (mapList.get((int)_position).containsKey("image")) {
				image_post.setVisibility(View.VISIBLE);
				Glide.with(getApplicationContext()).load(Uri.parse(mapList.get((int)_position).get("image").toString())).into(image_post);
			}
			else {
				image_post.setVisibility(View.GONE);
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
