package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.Button;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class ChatBotActivity extends AppCompatActivity {
	
	
	private FloatingActionButton _fab;
	private HashMap<String, Object> mapp = new HashMap<>();
	private String RustyUser = "";
	
	private ArrayList<String> rustyUser = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear0;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private AdView adview1;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear4;
	private Button button1;
	private Button button2;
	private LinearLayout linear402;
	private WebView webview1;
	private ImageView imageview1;
	private TextView text_of_rustia;
	private LinearLayout linear400;
	private TextView show_parts;
	private EditText text_to_send;
	private Button start_rustia;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat_bot);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear0 = (LinearLayout) findViewById(R.id.linear0);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		adview1 = (AdView) findViewById(R.id.adview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		linear402 = (LinearLayout) findViewById(R.id.linear402);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		text_of_rustia = (TextView) findViewById(R.id.text_of_rustia);
		linear400 = (LinearLayout) findViewById(R.id.linear400);
		show_parts = (TextView) findViewById(R.id.show_parts);
		text_to_send = (EditText) findViewById(R.id.text_to_send);
		start_rustia = (Button) findViewById(R.id.start_rustia);
		d = new AlertDialog.Builder(this);
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear4.setVisibility(View.VISIBLE);
				linear2.setVisibility(View.VISIBLE);
				start_rustia.setVisibility(View.VISIBLE);
				linear3.setVisibility(View.GONE);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear5.setVisibility(View.VISIBLE);
				linear2.setVisibility(View.VISIBLE);
				
				linear2.setVisibility(View.GONE);
				linear3.setVisibility(View.GONE);
				webview1.loadUrl("http://tlk.io/rusty-chat");
				webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		start_rustia.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				text_of_rustia.setText(text_of_rustia.getText().toString().concat("\n\nWrite the number \"#\" followed by the number to talk whit you {:3}"));
				show_parts.setText("Home -> #1\nAddons -> #2\nTotal convertion ->3\nMaps -> #4\nUploads -> #5\nDownloads -> #6\nNews -> #7\nClash of warfare -> #8\nTournaments -> #9\nCommunity -> #10\nMore -> #11");
				if (text_to_send.getText().toString().contains("#1")) {
					text_of_rustia.setText("\"Is this the Menu? {._.}\" \n\nYou could say my house, here you will see the most important thing to highlight, you can see the active members in Discord; enter our Facebook and see more ...");
				}
				if (text_to_send.getText().toString().contains("#2")) {
					text_of_rustia.setText("\"I'm sure this was not before { :° }\"\n\nIn this part you can collect mods and the best of all is that you can join them because they have not replaced units such as Command Center or Builder");
				}
				if (text_to_send.getText().toString().contains("#3")) {
					text_of_rustia.setText("\"By DIES, {x/ } that has happened to the game\"\n\nOn this part you will have the option to play with MODS in which you will modify the game, give you a different game experience");
				}
				if (text_to_send.getText().toString().contains("#4")) {
					text_of_rustia.setText("\"This place likes because I can go out and see the whole world { :3 }\" \n\nHere you will explore and play in all types of maps, large, small, strange, interesting and more");
				}
				if (text_to_send.getText().toString().contains("#5")) {
					text_of_rustia.setText("\"Up, U{:b }, SUBE AT UP \"\n\nHere you can upload games modes such as Addons, Total Convertion or maps in this\" grandiose \"(as I do {:3} ) app");
				}
				if (text_to_send.getText().toString().contains("#6")) {
					text_of_rustia.setText("\"The most downloaded {:Π }\"\n\nOnly see in installs mods and maps to play epic items");
				}
				if (text_to_send.getText().toString().contains("#7")) {
					text_of_rustia.setText("\"You knew that ... {= ( } I am an rusty reporter\"\n\nHere I bring you the most heatic news, the novelties of the rustic world, the version and most interesting things");
				}
				if (text_to_send.getText().toString().contains("#8")) {
					text_of_rustia.setText("\"A for them, not because of me {:'(  }\"\n\nHere you can put into practice for the true challenge several of those reds will come to your base and you will only be able to defend us");
				}
				if (text_to_send.getText().toString().contains("#9")) {
					text_of_rustia.setText("\"Nooo! They broke me in 3 seconds\"\n\nYou want to know if you are enough to skill for victory, the honor, get the well-deserved award and more enter PSS.");
				}
				if (text_to_send.getText().toString().contains("#10")) {
					text_of_rustia.setText("\"We are connected { :)  }\"\n\n A group socially suitable for people like you and not as");
				}
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i);
				finish();
			}
		});
	}
	private void initializeLogic() {
		linear2.setVisibility(View.GONE);
		linear4.setVisibility(View.GONE);
		linear5.setVisibility(View.GONE);
		start_rustia.setVisibility(View.GONE);
		adview1.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
		.build());
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		d.setTitle("Do you really want to leave the app?");
		d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		d.setNegativeButton("Go Home", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				d.create().show();
				i.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i);
				finish();
			}
		});
		d.create().show();
	}
	private void _ChatBot_V2 (final String _question, final String _What) {
		if (text_to_send.getText().toString().toLowerCase().contains(_question.toLowerCase())) {
			text_of_rustia.setText(_What);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
