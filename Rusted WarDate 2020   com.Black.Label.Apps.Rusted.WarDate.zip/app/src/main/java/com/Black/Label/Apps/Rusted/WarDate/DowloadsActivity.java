package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.ClipData;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.AdapterView;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class DowloadsActivity extends AppCompatActivity {
	
	public final int REQ_CD_F = 101;
	private Timer _timer = new Timer();
	
	private FloatingActionButton _fab;
	private String folder = "";
	private double n = 0;
	private String UPfolder = "";
	private String output = "";
	private String src = "";
	private String output0 = "";
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear533;
	private LinearLayout main;
	private AdView adview1;
	private LinearLayout menu;
	private LinearLayout linear509;
	private ImageView imageview119;
	private ScrollView vscroll2;
	private LinearLayout linear516;
	private LinearLayout linear517;
	private LinearLayout linear518;
	private LinearLayout linear519;
	private LinearLayout linear520;
	private LinearLayout linear521;
	private LinearLayout linear522;
	private LinearLayout linear523;
	private LinearLayout linear524;
	private LinearLayout linear525;
	private LinearLayout linear526;
	private LinearLayout linear527;
	private LinearLayout linear528;
	private LinearLayout linear529;
	private LinearLayout linear530;
	private LinearLayout linear531;
	private LinearLayout linear532;
	private ImageView imageview120;
	private TextView textview280;
	private ImageView imageview121;
	private TextView textview281;
	private ImageView imageview122;
	private TextView textview282;
	private ImageView imageview123;
	private TextView textview283;
	private ImageView imageview124;
	private TextView textview284;
	private ImageView imageview125;
	private TextView textview285;
	private ImageView imageview126;
	private TextView textview286;
	private ImageView imageview127;
	private TextView textview287;
	private ImageView imageview128;
	private TextView textview288;
	private ImageView imageview129;
	private TextView textview289;
	private ImageView imageview130;
	private TextView textview290;
	private ImageView imageview131;
	private TextView textview291;
	private TextView textview1;
	private LinearLayout fileexplorer;
	private LinearLayout second_menu;
	private ListView listview1;
	private LinearLayout linear514;
	private LinearLayout install;
	private LinearLayout launch_game;
	private TextView instmod;
	private TextView instmap;
	private TextView launchgame;
	private ImageView imageview118;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private AlertDialog.Builder d1;
	private Intent f = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dowloads);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear533 = (LinearLayout) findViewById(R.id.linear533);
		main = (LinearLayout) findViewById(R.id.main);
		adview1 = (AdView) findViewById(R.id.adview1);
		menu = (LinearLayout) findViewById(R.id.menu);
		linear509 = (LinearLayout) findViewById(R.id.linear509);
		imageview119 = (ImageView) findViewById(R.id.imageview119);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear516 = (LinearLayout) findViewById(R.id.linear516);
		linear517 = (LinearLayout) findViewById(R.id.linear517);
		linear518 = (LinearLayout) findViewById(R.id.linear518);
		linear519 = (LinearLayout) findViewById(R.id.linear519);
		linear520 = (LinearLayout) findViewById(R.id.linear520);
		linear521 = (LinearLayout) findViewById(R.id.linear521);
		linear522 = (LinearLayout) findViewById(R.id.linear522);
		linear523 = (LinearLayout) findViewById(R.id.linear523);
		linear524 = (LinearLayout) findViewById(R.id.linear524);
		linear525 = (LinearLayout) findViewById(R.id.linear525);
		linear526 = (LinearLayout) findViewById(R.id.linear526);
		linear527 = (LinearLayout) findViewById(R.id.linear527);
		linear528 = (LinearLayout) findViewById(R.id.linear528);
		linear529 = (LinearLayout) findViewById(R.id.linear529);
		linear530 = (LinearLayout) findViewById(R.id.linear530);
		linear531 = (LinearLayout) findViewById(R.id.linear531);
		linear532 = (LinearLayout) findViewById(R.id.linear532);
		imageview120 = (ImageView) findViewById(R.id.imageview120);
		textview280 = (TextView) findViewById(R.id.textview280);
		imageview121 = (ImageView) findViewById(R.id.imageview121);
		textview281 = (TextView) findViewById(R.id.textview281);
		imageview122 = (ImageView) findViewById(R.id.imageview122);
		textview282 = (TextView) findViewById(R.id.textview282);
		imageview123 = (ImageView) findViewById(R.id.imageview123);
		textview283 = (TextView) findViewById(R.id.textview283);
		imageview124 = (ImageView) findViewById(R.id.imageview124);
		textview284 = (TextView) findViewById(R.id.textview284);
		imageview125 = (ImageView) findViewById(R.id.imageview125);
		textview285 = (TextView) findViewById(R.id.textview285);
		imageview126 = (ImageView) findViewById(R.id.imageview126);
		textview286 = (TextView) findViewById(R.id.textview286);
		imageview127 = (ImageView) findViewById(R.id.imageview127);
		textview287 = (TextView) findViewById(R.id.textview287);
		imageview128 = (ImageView) findViewById(R.id.imageview128);
		textview288 = (TextView) findViewById(R.id.textview288);
		imageview129 = (ImageView) findViewById(R.id.imageview129);
		textview289 = (TextView) findViewById(R.id.textview289);
		imageview130 = (ImageView) findViewById(R.id.imageview130);
		textview290 = (TextView) findViewById(R.id.textview290);
		imageview131 = (ImageView) findViewById(R.id.imageview131);
		textview291 = (TextView) findViewById(R.id.textview291);
		textview1 = (TextView) findViewById(R.id.textview1);
		fileexplorer = (LinearLayout) findViewById(R.id.fileexplorer);
		second_menu = (LinearLayout) findViewById(R.id.second_menu);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear514 = (LinearLayout) findViewById(R.id.linear514);
		install = (LinearLayout) findViewById(R.id.install);
		launch_game = (LinearLayout) findViewById(R.id.launch_game);
		instmod = (TextView) findViewById(R.id.instmod);
		instmap = (TextView) findViewById(R.id.instmap);
		launchgame = (TextView) findViewById(R.id.launchgame);
		imageview118 = (ImageView) findViewById(R.id.imageview118);
		d = new AlertDialog.Builder(this);
		d1 = new AlertDialog.Builder(this);
		f.setType("*/*");
		f.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		imageview119.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Back_Menu();
			}
		});
		
		textview280.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview281.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ChatBotActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview282.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), AddonsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview283.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), TotalconvertionActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview284.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), MapsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview285.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), RwdUploadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview287.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Get Rusty Maker in Play Store");
				Intent launchi = getPackageManager().getLaunchIntentForPackage("com.Black.Label.Apps.RustyMaker");
				if (launchi != null)
				{
					showMessage("Opening RustyMaker");
					startActivity(launchi);
				}
			}
		});
		
		textview288.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ClashofwarfareActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview289.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setData(Uri.parse("https://sites.google.com/view/upload-in-wardate/tournaments"));
				i.setAction(Intent.ACTION_VIEW);
				startActivity(i);
			}
		});
		
		textview290.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), FbpostsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview291.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Comingsoon !");
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (FileUtil.isDirectory(list.get((int)(_position)))) {
					folder = list.get((int)(_position));
					textview1.setText(list.get((int)(_position)));
					_refreshList();
				}
				else {
					second_menu.setVisibility(View.INVISIBLE);
					install.setVisibility(View.VISIBLE);
					launch_game.setVisibility(View.GONE);
					_refreshList();
					SketchwareUtil.showMessage(getApplicationContext(), "Long press to Install !!");
				}
				if (list.get((int)(_position)).equals(FileUtil.getExternalStorageDir().concat("/rustedWarfare/Rusted_WarDate/MODS/"))) {
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									second_menu.setVisibility(View.VISIBLE);
									install.setVisibility(View.VISIBLE);
									instmod.setVisibility(View.VISIBLE);
									instmap.setVisibility(View.GONE);
									launch_game.setVisibility(View.GONE);
									_refreshList();
								}
							});
						}
					};
					_timer.schedule(t, (int)(4000));
				}
				if (list.get((int)(_position)).equals(FileUtil.getExternalStorageDir().concat("/rustedWarfare/Rusted_WarDate/MAPS/"))) {
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									second_menu.setVisibility(View.VISIBLE);
									install.setVisibility(View.VISIBLE);
									instmod.setVisibility(View.GONE);
									instmap.setVisibility(View.VISIBLE);
									launch_game.setVisibility(View.GONE);
									_refreshList();
								}
							});
						}
					};
					_timer.schedule(t, (int)(4000));
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				textview1.setText(list.get((int)(_position)));
				second_menu.setVisibility(View.VISIBLE);
				install.setVisibility(View.VISIBLE);
				launch_game.setVisibility(View.GONE);
				return true;
			}
		});
		
		instmod.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("Wish?");
				d.setPositiveButton(" Intall in \nthe game", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						Intent launchi = getPackageManager().getLaunchIntentForPackage("com.corrodinggames.rts");
						if (launchi != null)
						{
							startActivity(launchi);
						}
						SketchwareUtil.showMessage(getApplicationContext(), "");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "RustIA is opening the game\n.............");
						SketchwareUtil.showMessage(getApplicationContext(), "1. Go to Setting");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "2. Go a Mods");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "3. Clic in Import");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "4. Go at \n\n\"/rustedWarfare/Rusted_WarDate/MODS/\"");
						SketchwareUtil.showMessage(getApplicationContext(), "4. Go at \n\n\"/rustedWarfare/Rusted_WarDate/MODS/\"");
						SketchwareUtil.showMessage(getApplicationContext(), "...");
						SketchwareUtil.showMessage(getApplicationContext(), "5. And press in Import");
					}
				});
				d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		instmap.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("Wish?");
				d.setPositiveButton(" Only\nInstall", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						src = textview1.getText().toString();
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										_extract(src, output);
										SketchwareUtil.showMessage(getApplicationContext(), "The Map has been installed!");
										launch_game.setVisibility(View.VISIBLE);
										install.setVisibility(View.GONE);
									}
								});
							}
						};
						_timer.schedule(t, (int)(3000));
					}
				});
				d.setNegativeButton(" Install &\nClean file", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						src = textview1.getText().toString();
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										_extract(src, output);
										SketchwareUtil.showMessage(getApplicationContext(), "The Map has been installed!");
										launch_game.setVisibility(View.VISIBLE);
										install.setVisibility(View.GONE);
										SketchwareUtil.showMessage(getApplicationContext(), "RustIA has deleted the residual file !");
										FileUtil.deleteFile(textview1.getText().toString());
									}
								});
							}
						};
						_timer.schedule(t, (int)(3000));
					}
				});
				d.create().show();
				_refreshList();
			}
		});
		
		launchgame.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent launchi = getPackageManager().getLaunchIntentForPackage("com.corrodinggames.rts");
				if (launchi != null)
				{
					startActivity(launchi);
				}
			}
		});
		
		imageview118.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent launchi = getPackageManager().getLaunchIntentForPackage("com.corrodinggames.rts");
				if (launchi != null)
				{
					startActivity(launchi);
				}
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				menu.setVisibility(View.VISIBLE);
				fileexplorer.setVisibility(View.GONE);
			}
		});
	}
	private void initializeLogic() {
		second_menu.setVisibility(View.GONE);
		_Hide_Menu();
		folder = FileUtil.getExternalStorageDir().concat("/rustedWarfare/Rusted_WarDate/");
		_refreshList();
		output0 = FileUtil.getExternalStorageDir().concat("/rustedWarfare/units/");
		if (!FileUtil.isExistFile(output0)) {
			FileUtil.makeDir(output0);
		}
		output = FileUtil.getExternalStorageDir().concat("/rustedWarfare/maps/");
		if (!FileUtil.isExistFile(output)) {
			FileUtil.makeDir(output);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_F:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		adview1.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
		.build());
		second_menu.setVisibility(View.GONE);
		_Back_Menu();
		if (folder.equals(FileUtil.getExternalStorageDir().concat("/rustedWarfare/Rusted_WarDate/"))) {
			d.setTitle("Do you really want to leave the app?");
			d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finishAffinity();
				}
			});
			d.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			d.create().show();
		}
		else {
			UPfolder = folder.substring((int)(0), (int)(folder.lastIndexOf("/")));
			folder = UPfolder;
			_refreshList();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_refreshList();
	}
	private void _Hide_Menu () {
		menu.setVisibility(View.GONE);
		fileexplorer.setVisibility(View.VISIBLE);
	}
	
	
	private void _Back_Menu () {
		fileexplorer.setVisibility(View.VISIBLE);
		menu.setVisibility(View.GONE);
	}
	
	
	private void _refreshList () {
		listmap.clear();
		FileUtil.listDir(folder, list);
		//Simple shorting
		
		Collections.sort(list);
		n = 0;
		for(int _repeat16 = 0; _repeat16 < (int)(list.size()); _repeat16++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("file", list.get((int)(n)));
				listmap.add(_item);
			}
			
			n++;
		}
		listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _extract (final String _src, final String _output) {
		UnZip unZip = new UnZip();
		unZip.unZipIt(_src, _output);
	}
	
	
	private void _library () {
	}
	
	public class UnZip {
		List<String> fileList;
		
		public void unZipIt(String zipFile, String outputFolder){
			byte[] buffer = new byte[1024];
			try{
				java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(new java.io.FileInputStream(zipFile));
				java.util.zip.ZipEntry ze = zis.getNextEntry();
				while(ze!=null){
					String fileName = ze.getName();
					java.io.File newFile = new java.io.File(outputFolder + java.io.File.separator + fileName);
					new java.io.File(newFile.getParent()).mkdirs();
					java.io.FileOutputStream fos = new java.io.FileOutputStream(newFile);
					int len;
					while ((len = zis.read(buffer)) > 0) {
						fos.write(buffer, 0, len);
					}
					fos.close();
					ze = zis.getNextEntry(); 
				}
				zis.closeEntry();
				zis.close();
			}catch(java.io.IOException ex){
				ex.printStackTrace();
			}
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cview, null);
			}
			
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			textview1.setText(Uri.parse(list.get((int)(_position))).getLastPathSegment());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
