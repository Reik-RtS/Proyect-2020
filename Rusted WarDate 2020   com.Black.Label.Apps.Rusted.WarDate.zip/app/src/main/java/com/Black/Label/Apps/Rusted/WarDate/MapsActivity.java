package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;

public class MapsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private FloatingActionButton _fab;
	private String command = "";
	private boolean connected = false;
	
	private LinearLayout linear1;
	private LinearLayout pl;
	private LinearLayout main;
	private AdView adview1;
	private LinearLayout menu;
	private WebView webview1;
	private LinearLayout no_connection;
	private ImageView imageview118;
	private ScrollView vscroll2;
	private LinearLayout linear510;
	private LinearLayout linear511;
	private LinearLayout linear512;
	private LinearLayout linear513;
	private LinearLayout linear514;
	private LinearLayout linear515;
	private LinearLayout linear516;
	private LinearLayout linear517;
	private LinearLayout linear518;
	private LinearLayout linear519;
	private LinearLayout linear520;
	private LinearLayout linear521;
	private LinearLayout linear522;
	private LinearLayout linear523;
	private LinearLayout linear524;
	private LinearLayout linear525;
	private LinearLayout linear527;
	private ImageView imageview119;
	private TextView textview280;
	private ImageView imageview120;
	private TextView textview281;
	private ImageView imageview121;
	private TextView textview282;
	private ImageView imageview122;
	private TextView textview283;
	private ImageView imageview123;
	private TextView textview284;
	private ImageView imageview124;
	private TextView textview285;
	private ImageView imageview125;
	private TextView textview286;
	private ImageView imageview126;
	private TextView textview287;
	private ImageView imageview127;
	private TextView textview288;
	private ImageView imageview128;
	private TextView textview289;
	private ImageView imageview129;
	private TextView textview290;
	private ImageView imageview130;
	private TextView textview291;
	private ImageView imagenoconnection;
	private TextView textnoconnection;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private InterstitialAd ita;
	private AdListener _ita_ad_listener;
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.maps);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		pl = (LinearLayout) findViewById(R.id.pl);
		main = (LinearLayout) findViewById(R.id.main);
		adview1 = (AdView) findViewById(R.id.adview1);
		menu = (LinearLayout) findViewById(R.id.menu);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		no_connection = (LinearLayout) findViewById(R.id.no_connection);
		imageview118 = (ImageView) findViewById(R.id.imageview118);
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear510 = (LinearLayout) findViewById(R.id.linear510);
		linear511 = (LinearLayout) findViewById(R.id.linear511);
		linear512 = (LinearLayout) findViewById(R.id.linear512);
		linear513 = (LinearLayout) findViewById(R.id.linear513);
		linear514 = (LinearLayout) findViewById(R.id.linear514);
		linear515 = (LinearLayout) findViewById(R.id.linear515);
		linear516 = (LinearLayout) findViewById(R.id.linear516);
		linear517 = (LinearLayout) findViewById(R.id.linear517);
		linear518 = (LinearLayout) findViewById(R.id.linear518);
		linear519 = (LinearLayout) findViewById(R.id.linear519);
		linear520 = (LinearLayout) findViewById(R.id.linear520);
		linear521 = (LinearLayout) findViewById(R.id.linear521);
		linear522 = (LinearLayout) findViewById(R.id.linear522);
		linear523 = (LinearLayout) findViewById(R.id.linear523);
		linear524 = (LinearLayout) findViewById(R.id.linear524);
		linear525 = (LinearLayout) findViewById(R.id.linear525);
		linear527 = (LinearLayout) findViewById(R.id.linear527);
		imageview119 = (ImageView) findViewById(R.id.imageview119);
		textview280 = (TextView) findViewById(R.id.textview280);
		imageview120 = (ImageView) findViewById(R.id.imageview120);
		textview281 = (TextView) findViewById(R.id.textview281);
		imageview121 = (ImageView) findViewById(R.id.imageview121);
		textview282 = (TextView) findViewById(R.id.textview282);
		imageview122 = (ImageView) findViewById(R.id.imageview122);
		textview283 = (TextView) findViewById(R.id.textview283);
		imageview123 = (ImageView) findViewById(R.id.imageview123);
		textview284 = (TextView) findViewById(R.id.textview284);
		imageview124 = (ImageView) findViewById(R.id.imageview124);
		textview285 = (TextView) findViewById(R.id.textview285);
		imageview125 = (ImageView) findViewById(R.id.imageview125);
		textview286 = (TextView) findViewById(R.id.textview286);
		imageview126 = (ImageView) findViewById(R.id.imageview126);
		textview287 = (TextView) findViewById(R.id.textview287);
		imageview127 = (ImageView) findViewById(R.id.imageview127);
		textview288 = (TextView) findViewById(R.id.textview288);
		imageview128 = (ImageView) findViewById(R.id.imageview128);
		textview289 = (TextView) findViewById(R.id.textview289);
		imageview129 = (ImageView) findViewById(R.id.imageview129);
		textview290 = (TextView) findViewById(R.id.textview290);
		imageview130 = (ImageView) findViewById(R.id.imageview130);
		textview291 = (TextView) findViewById(R.id.textview291);
		imagenoconnection = (ImageView) findViewById(R.id.imagenoconnection);
		textnoconnection = (TextView) findViewById(R.id.textnoconnection);
		d = new AlertDialog.Builder(this);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (connected) {
					no_connection.setVisibility(View.GONE);
					linear1.setVisibility(View.VISIBLE);
					
				}
				else {
					no_connection.setVisibility(View.VISIBLE);
					webview1.setVisibility(View.GONE);
					
				}
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		imageview118.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Back_Menu();
			}
		});
		
		linear522.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ClashofwarfareActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview280.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview281.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ChatBotActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview282.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), AddonsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview283.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), TotalconvertionActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview284.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		textview285.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), RwdUploadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview286.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), DowloadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview287.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Get Rusty Maker in Play Store");
				Intent launchi = getPackageManager().getLaunchIntentForPackage("com.Black.Label.Apps.RustyMaker");
				if (launchi != null)
				{
					showMessage("Opening RustyMaker");
					startActivity(launchi);
				}
			}
		});
		
		textview289.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setData(Uri.parse("https://sites.google.com/view/upload-in-wardate/tournaments"));
				i.setAction(Intent.ACTION_VIEW);
				startActivity(i);
			}
		});
		
		textview290.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), FbpostsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview291.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Comingsoon !");
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				menu.setVisibility(View.VISIBLE);
				webview1.setVisibility(View.GONE);
				no_connection.setVisibility(View.GONE);
			}
		});
		
		_ita_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				ita.setAdUnitId("ca-app-pub-8924286307600337/5569491188");
				ita.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
				.build());
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		_Hide_Menu();
		_Progress_bar();
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
				String cookies = CookieManager.getInstance().getCookie(url);
				request.addRequestHeader("cookie", cookies);
				request.addRequestHeader("User-Agent", userAgent);
				request.setDescription("Downloading Map ...");
				request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "/rustedWarfare/RustedWarDate/MAPS/");
				if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir("/rustedWarfare/RustedWarDate/MAPS/", URLUtil.guessFileName(url, contentDisposition, mimetype));
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				manager.enqueue(request);
				showMessage("Downloading Map ....");
				//Notif if success
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		_TryConnection();
		no_connection.setVisibility(View.GONE);
		webview1.setVisibility(View.VISIBLE);
		webview1.loadUrl("http://rusted7wardate7maps.blogspot.com/");
		webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
		if (connected) {
			pl.setVisibility(View.VISIBLE);
			adview1.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
			.build());
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							ita = new InterstitialAd(getApplicationContext());
							ita.setAdListener(_ita_ad_listener);
							ita.setAdUnitId("ca-app-pub-8924286307600337/5569491188");
							ita.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
							.build());
							ita.show();
						}
					});
				}
			};
			_timer.schedule(t, (int)(12000));
		}
		else {
			pl.setVisibility(View.GONE);
			no_connection.setVisibility(View.VISIBLE);
			webview1.setVisibility(View.GONE);
			menu.setVisibility(View.GONE);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (connected) {
			if (webview1.canGoBack()) {
				webview1.goBack();
			}
			else {
				_Back_Menu();
				d.setTitle("Do you really want to leave the app?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finishAffinity();
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		}
		else {
			no_connection.setVisibility(View.VISIBLE);
			webview1.setVisibility(View.GONE);
			menu.setVisibility(View.GONE);
		}
	}
	private void _TryConnection () {
		command = "ping -c 1 google.com";
		try{
			connected = (Runtime.getRuntime().exec (command).waitFor() == 0);
		} 
		catch (Exception e){
			showMessage(e.toString());}
	}
	
	
	private void _Progress_bar () {
		final android.widget.ProgressBar prog = new android.widget.ProgressBar(this,null, android.R.attr.progressBarStyleHorizontal);
		
		prog.setPadding(0,0,0,0);
		
		prog.setIndeterminate(false);
		
		prog.setFitsSystemWindows(true);
		
		prog.setProgress(0);
		
		prog.setScrollBarStyle(android.widget.ProgressBar.SCROLLBARS_OUTSIDE_INSET);
		
		prog.setMax(100);
		
		ViewGroup.LayoutParams vlp = new ViewGroup.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		
		prog.setLayoutParams(vlp);
		
		pl.addView(prog);
		
		webview1.setWebChromeClient(new WebChromeClient() {
			
			@Override public void onProgressChanged(WebView view, int newProgress) {
				
				prog.setProgress(newProgress);
				
			}
			
		});
	}
	
	
	private void _Hide_Menu () {
		menu.setVisibility(View.GONE);
		linear1.setVisibility(View.VISIBLE);
		no_connection.setVisibility(View.GONE);
	}
	
	
	private void _Back_Menu () {
		if (connected) {
			menu.setVisibility(View.GONE);
			webview1.setVisibility(View.VISIBLE);
			no_connection.setVisibility(View.GONE);
		}
		else {
			no_connection.setVisibility(View.VISIBLE);
			webview1.setVisibility(View.GONE);
			menu.setVisibility(View.GONE);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
