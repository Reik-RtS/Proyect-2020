package com.Black.Label.Apps.Rusted.WarDate;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class FbpostsActivity extends AppCompatActivity {
	
	
	private FloatingActionButton _fab;
	private String command = "";
	private boolean connected = false;
	
	private LinearLayout linear1;
	private AdView adview1;
	private LinearLayout pl;
	private LinearLayout main;
	private LinearLayout menu;
	private WebView webview1;
	private LinearLayout no_connection;
	private ImageView imageview131;
	private ScrollView vscroll3;
	private LinearLayout linear527;
	private LinearLayout linear528;
	private LinearLayout linear529;
	private LinearLayout linear530;
	private LinearLayout linear531;
	private LinearLayout linear532;
	private LinearLayout linear533;
	private LinearLayout linear534;
	private LinearLayout linear535;
	private LinearLayout linear536;
	private LinearLayout linear537;
	private LinearLayout linear538;
	private LinearLayout linear539;
	private LinearLayout linear540;
	private LinearLayout linear541;
	private LinearLayout linear542;
	private LinearLayout linear510;
	private ImageView imageview132;
	private TextView textview292;
	private ImageView imageview133;
	private TextView textview293;
	private ImageView imageview134;
	private TextView textview294;
	private ImageView imageview135;
	private TextView textview295;
	private ImageView imageview136;
	private TextView textview296;
	private ImageView imageview137;
	private TextView textview297;
	private ImageView imageview138;
	private TextView textview298;
	private ImageView imageview139;
	private TextView textview299;
	private ImageView imageview140;
	private TextView textview300;
	private ImageView imageview141;
	private TextView textview301;
	private ImageView imageview142;
	private TextView textview302;
	private ImageView imageview143;
	private TextView textview303;
	private ImageView imagenoconnection;
	private TextView textnoconnection;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.fbposts);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		adview1 = (AdView) findViewById(R.id.adview1);
		pl = (LinearLayout) findViewById(R.id.pl);
		main = (LinearLayout) findViewById(R.id.main);
		menu = (LinearLayout) findViewById(R.id.menu);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		no_connection = (LinearLayout) findViewById(R.id.no_connection);
		imageview131 = (ImageView) findViewById(R.id.imageview131);
		vscroll3 = (ScrollView) findViewById(R.id.vscroll3);
		linear527 = (LinearLayout) findViewById(R.id.linear527);
		linear528 = (LinearLayout) findViewById(R.id.linear528);
		linear529 = (LinearLayout) findViewById(R.id.linear529);
		linear530 = (LinearLayout) findViewById(R.id.linear530);
		linear531 = (LinearLayout) findViewById(R.id.linear531);
		linear532 = (LinearLayout) findViewById(R.id.linear532);
		linear533 = (LinearLayout) findViewById(R.id.linear533);
		linear534 = (LinearLayout) findViewById(R.id.linear534);
		linear535 = (LinearLayout) findViewById(R.id.linear535);
		linear536 = (LinearLayout) findViewById(R.id.linear536);
		linear537 = (LinearLayout) findViewById(R.id.linear537);
		linear538 = (LinearLayout) findViewById(R.id.linear538);
		linear539 = (LinearLayout) findViewById(R.id.linear539);
		linear540 = (LinearLayout) findViewById(R.id.linear540);
		linear541 = (LinearLayout) findViewById(R.id.linear541);
		linear542 = (LinearLayout) findViewById(R.id.linear542);
		linear510 = (LinearLayout) findViewById(R.id.linear510);
		imageview132 = (ImageView) findViewById(R.id.imageview132);
		textview292 = (TextView) findViewById(R.id.textview292);
		imageview133 = (ImageView) findViewById(R.id.imageview133);
		textview293 = (TextView) findViewById(R.id.textview293);
		imageview134 = (ImageView) findViewById(R.id.imageview134);
		textview294 = (TextView) findViewById(R.id.textview294);
		imageview135 = (ImageView) findViewById(R.id.imageview135);
		textview295 = (TextView) findViewById(R.id.textview295);
		imageview136 = (ImageView) findViewById(R.id.imageview136);
		textview296 = (TextView) findViewById(R.id.textview296);
		imageview137 = (ImageView) findViewById(R.id.imageview137);
		textview297 = (TextView) findViewById(R.id.textview297);
		imageview138 = (ImageView) findViewById(R.id.imageview138);
		textview298 = (TextView) findViewById(R.id.textview298);
		imageview139 = (ImageView) findViewById(R.id.imageview139);
		textview299 = (TextView) findViewById(R.id.textview299);
		imageview140 = (ImageView) findViewById(R.id.imageview140);
		textview300 = (TextView) findViewById(R.id.textview300);
		imageview141 = (ImageView) findViewById(R.id.imageview141);
		textview301 = (TextView) findViewById(R.id.textview301);
		imageview142 = (ImageView) findViewById(R.id.imageview142);
		textview302 = (TextView) findViewById(R.id.textview302);
		imageview143 = (ImageView) findViewById(R.id.imageview143);
		textview303 = (TextView) findViewById(R.id.textview303);
		imagenoconnection = (ImageView) findViewById(R.id.imagenoconnection);
		textnoconnection = (TextView) findViewById(R.id.textnoconnection);
		d = new AlertDialog.Builder(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		imageview131.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Back_Menu();
			}
		});
		
		textview292.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview293.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ChatBotActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview294.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), AddonsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview295.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), TotalconvertionActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview296.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), MapsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview297.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), RwdUploadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview298.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), DowloadsActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview299.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Get Rusty Maker in Play Store");
				Intent launchi = getPackageManager().getLaunchIntentForPackage("com.Black.Label.Apps.RustyMaker");
				if (launchi != null)
				{
					showMessage("Opening RustyMaker");
					startActivity(launchi);
				}
			}
		});
		
		textview300.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.create().show();
				i.setClass(getApplicationContext(), ClashofwarfareActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		textview301.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setData(Uri.parse("https://sites.google.com/view/upload-in-wardate/tournaments"));
				i.setAction(Intent.ACTION_VIEW);
				startActivity(i);
			}
		});
		
		textview303.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Comingsoon !");
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				no_connection.setVisibility(View.GONE);
				webview1.setVisibility(View.GONE);
				menu.setVisibility(View.VISIBLE);
			}
		});
	}
	private void initializeLogic() {
		adview1.loadAd(new AdRequest.Builder().addTestDevice("CE38960E1409791E1AE17080754937B0")
		.build());
		_Hide_Menu();
		_Progress_bar();
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
				String cookies = CookieManager.getInstance().getCookie(url);
				request.addRequestHeader("cookie", cookies);
				request.addRequestHeader("User-Agent", userAgent);
				request.setDescription("Downloading Mod ...");
				request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "rustedWarfare/RustyMaker/Mod/TotalConvertion/");
				if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir("rustedWarfare/RustyMaker/Mod/TotalConvertion/", URLUtil.guessFileName(url, contentDisposition, mimetype));
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				manager.enqueue(request);
				showMessage("Downloading Mod ....");
				//Notif if success
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		_TryConnection();
		no_connection.setVisibility(View.GONE);
		webview1.setVisibility(View.VISIBLE);
		webview1.loadUrl("https://www.facebook.com/groups/1674673552823477/");
		webview1.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
		if (connected) {
			
		}
		else {
			no_connection.setVisibility(View.VISIBLE);
			webview1.setVisibility(View.GONE);
			menu.setVisibility(View.GONE);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (webview1.canGoBack()) {
			webview1.goBack();
		}
		else {
			_Back_Menu();
			d.setTitle("Do you really want to leave the app?");
			d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finishAffinity();
				}
			});
			d.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			d.create().show();
		}
	}
	private void _TryConnection () {
		command = "ping -c 1 google.com";
		try{
			connected = (Runtime.getRuntime().exec (command).waitFor() == 0);
		} 
		catch (Exception e){
			showMessage(e.toString());}
	}
	
	
	private void _Progress_bar () {
		final android.widget.ProgressBar prog = new android.widget.ProgressBar(this,null, android.R.attr.progressBarStyleHorizontal);
		
		prog.setPadding(0,0,0,0);
		
		prog.setIndeterminate(false);
		
		prog.setFitsSystemWindows(true);
		
		prog.setProgress(0);
		
		prog.setScrollBarStyle(android.widget.ProgressBar.SCROLLBARS_OUTSIDE_INSET);
		
		prog.setMax(100);
		
		ViewGroup.LayoutParams vlp = new ViewGroup.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		
		prog.setLayoutParams(vlp);
		
		pl.addView(prog);
		
		webview1.setWebChromeClient(new WebChromeClient() {
			
			@Override public void onProgressChanged(WebView view, int newProgress) {
				
				prog.setProgress(newProgress);
				
			}
			
		});
	}
	
	
	private void _Hide_Menu () {
		menu.setVisibility(View.GONE);
		linear1.setVisibility(View.VISIBLE);
		no_connection.setVisibility(View.GONE);
	}
	
	
	private void _Back_Menu () {
		menu.setVisibility(View.GONE);
		webview1.setVisibility(View.VISIBLE);
		no_connection.setVisibility(View.GONE);
	}
	
	
	private void _Show_menu () {
		menu.setVisibility(View.VISIBLE);
		webview1.setVisibility(View.GONE);
		no_connection.setVisibility(View.GONE);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
